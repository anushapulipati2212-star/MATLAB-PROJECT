clc;
clear all;
close all; warning off;
functionname='OpenSurf.m';
functiondir=which(functionname);
functiondir=functiondir(1:end-length(functionname));
addpath([functiondir '/WarpFunctions'])

% Input images
[filename pathname]=uigetfile('*.jpg; *.png');
I1=imread([pathname filename]);
%I1 = imresize(I1,[512 512]);
figure(1); imshow(I1);
I11=rgb2gray(I1);figure(2); imshow(I11);title('Original Image');

[filename pathname]=uigetfile('*.jpg; *.png');
I2=imread([pathname filename]);
%I2 = imresize(I2,[512 512]);
figure(3); imshow(I2);
I22=rgb2gray(I2);
figure(4); imshow(I22);title('Testing Image');

%% Feature Selection
KP = detectSURFFeatures(uint8(I11));
figure(5);imshow(I11); hold on;
plot(KP.selectStrongest(10));

KP = detectSURFFeatures(uint8(I22));
figure(6);imshow(I22); hold on;
plot(KP.selectStrongest(10));

% Get the Key Points
Options.upright=true;
Options.tresh=0.0001;
Ipts1=OpenSurf(I1,Options);
Ipts2=OpenSurf(I2,Options);
% Put the landmark descriptors in a matrix
D1 = reshape([Ipts1.descriptor],64,[]);
D2 = reshape([Ipts2.descriptor],64,[]);
% Find the best matches
err=zeros(1,length(Ipts1));
cor1=1:length(Ipts1);
cor2=zeros(1,length(Ipts1));
for i=1:length(Ipts1)
    distance=sum((D2-repmat(D1(:,i),[1 length(Ipts2)])).^2,1);
    [err(i),cor2(i)]=min(distance);
end
% Sort matches on vector distance
[err, ind]=sort(err);
cor1=cor1(ind);
cor2=cor2(ind);
% Make vectors with the coordinates of the best matches
Pos1=[[Ipts1(cor1).y]',[Ipts1(cor1).x]'];
Pos2=[[Ipts2(cor2).y]',[Ipts2(cor2).x]'];
Pos1=Pos1(1:30,:);
Pos2=Pos2(1:30,:);
% Show both images
I = zeros([size(I1,1) size(I1,2)*2 size(I1,3)]);
I(:,1:size(I1,2),:)=I1; I(:,size(I1,2)+1:size(I1,2)+size(I2,2),:)=I2;
figure, imshow(I/255); hold on;
% Show the best matches
for i=1:30
    c=rand(1,3);
    plot([Ipts1(cor1(i)).x Ipts2(cor2(i)).x+size(I1,2)],[Ipts1(cor1(i)).y Ipts2(cor2(i)).y],'-','Color',c)
    plot([Ipts1(cor1(i)).x Ipts2(cor2(i)).x+size(I1,2)],[Ipts1(cor1(i)).y Ipts2(cor2(i)).y],'o','Color',c)
end
%%
% Show the best matches
plot([Pos1(:,2) Pos2(:,2)+size(I1,2)]',[Pos1(:,1) Pos2(:,1)]','-');
plot([Pos1(:,2) Pos2(:,2)+size(I1,2)]',[Pos1(:,1) Pos2(:,1)]','o');

% Calculate affine matrix
Pos1(:,3)=1; Pos2(:,3)=1;
M=Pos1'/Pos2';

% Warp the image
I1_warped=affine_warp(I1,M,0);

% Show the result
figure,
subplot(1,3,1), imshow(I1);title('Image 1');
subplot(1,3,2), imshow(I2);title('Image 2');
subplot(1,3,3), imshow(uint8(I1_warped));title('Warped Figure');